#!/bin/bash

chmod +x ejercicio3parte1.sh
echo; echo "Ejecutando parte 2"
./ejercicio3parte1.sh

chmod +x ejercicio3parte2.sh
echo; echo "Ejecutando parte 2"
./ejercicio3parte2.sh
