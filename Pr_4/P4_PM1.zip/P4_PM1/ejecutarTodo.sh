#!/bin/bash
cd Ej2
chmod +x ejercicio2.sh
echo "Ejecutando ejercicio 2"

./ejercicio2.sh

cd ..
cd Ej3

chmod +x ejercicio3.sh
echo; echo "Ejecutando ejercicio 3"
./ejercicio3.sh
