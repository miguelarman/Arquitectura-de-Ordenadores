#!/bin/bash
#
#$ -S /bin/bash
#$ -cwd
#$ -o salidatest.out
#$ -j y

ls
